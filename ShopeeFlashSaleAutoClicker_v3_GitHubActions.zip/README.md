# Shopee Flash Sale Auto Clicker v3

Versi ini sudah dilengkapi GitHub Actions untuk build APK tanpa komputer.

Fitur:
- Banyak jadwal.
- Waktu HH:mm:ss.
- Pilih titik klik langsung di layar.
- Ubah jadwal.
- Aktif/nonaktif jadwal.
- AccessibilityService untuk satu ketukan.
- Tidak melakukan checkout atau pembayaran otomatis.

## Build dari HP
1. Buat repository GitHub baru.
2. Upload seluruh isi proyek ini ke repository.
3. Pastikan branch utama bernama `main`.
4. Buka tab Actions.
5. Pilih workflow `Build Android APK`.
6. Tekan `Run workflow`.
7. Tunggu sampai selesai.
8. Buka hasil workflow dan bagian Artifacts.
9. Download `ShopeeFlashSaleAutoClicker-v3-debug`.
10. Ekstrak artifact tersebut dan install `app-debug.apk`.

Workflow memakai GitHub-hosted runner, JDK 17, Android SDK 35, dan Gradle 8.10.
